FALLEN SIGNAL — Windows x64 prototype

1. Extract this ZIP anywhere.
2. Double-click FallenSignal.exe.
3. No browser, CMake, Visual Studio, or game engine is required to run it.

Controls
  W A S D       Fast reticle / turret aim
  Arrow keys    Fine reticle aim
  + or = / -    Zoom in / out
  Left click or Space   Fire a projectile
  R             Reset encounter
  Esc           Release mouse; press it again to quit

Requires: Windows 10/11 x64 and a GPU/driver supporting OpenGL 3.3 or newer.
