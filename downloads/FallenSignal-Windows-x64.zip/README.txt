FALLEN SIGNAL — cinematic optic prototype, Windows x64

1. Extract this ZIP anywhere.
2. Keep angel_sprite.ppm beside FallenSignal.exe.
3. Double-click FallenSignal.exe.

No browser, CMake, Visual Studio, or game engine is needed to run it.

Controls
  W A S D             Fast, limited turret/optic aim
  Arrow keys          Fine aim
  + or = / -          Optical zoom
  Left click or Space Fire a finite-speed projectile
  R                   Reset encounter
  Esc                 Release mouse; press again to quit

Requires: Windows 10/11 x64 and a GPU/driver supporting OpenGL 3.3 or newer.
