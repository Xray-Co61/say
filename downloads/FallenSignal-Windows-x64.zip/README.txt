FALLEN SIGNAL — cinematic optic prototype, Windows x64

1. Extract this ZIP anywhere.
2. Double-click FallenSignal.exe.

No browser, CMake, Visual Studio, game engine, external image asset, or texture
is needed. The winged signals use dense, fully procedural 3D feather geometry;
the optic watches them from below as they cross above the player.

Controls
  W A S D             Fast, constrained turret/optic aim
  Arrow keys          Fine aim
  + or = / -          Optical zoom
  Left click or Space Fire a red ballistic shell
  R                   Reset encounter
  Esc                 Release mouse; press again to quit

Requires: Windows 10/11 x64 and a GPU/driver supporting OpenGL 3.3 or newer.
