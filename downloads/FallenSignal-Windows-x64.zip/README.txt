FALLEN SIGNAL — cinematic optic prototype, Windows x64

1. Extract this ZIP anywhere.
2. Double-click FallenSignal.exe.

No browser, CMake, Visual Studio, game engine, or external image asset is needed.
Distant winged signals are generated procedurally in the renderer and are viewed
from below. The cannon fires visible red ballistic shells.

Controls
  W A S D             Fast, constrained turret/optic aim
  Arrow keys          Fine aim
  + or = / -          Optical zoom
  Left click or Space Fire a red ballistic shell
  R                   Reset encounter
  Esc                 Release mouse; press again to quit

Requires: Windows 10/11 x64 and a GPU/driver supporting OpenGL 3.3 or newer.
