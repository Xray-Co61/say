FALLEN SIGNAL — cinematic optic prototype, Windows x64

1. Extract this ZIP anywhere.
2. Double-click FallenSignal.exe.

The game opens in native full screen so the targeting optic is not surrounded
by desktop chrome. No browser, CMake, Visual Studio, game engine, external
image asset, or texture is needed.

Winged signals are fully procedural 3D geometry: volumetric bodies, separate
feathers, coverts, and fan tails. The player views their underwings from below.
A close focal signal begins on the optic axis; other signals still arrive from
behind at varied distances and altitudes. The cannon fires finite red ballistic
shells with visible trails, travel time, target lead, and gravity drop.

Controls
  W A S D             Fast, constrained turret/optic aim
  Arrow keys          Fine aim
  + or = / -          Optical zoom
  Left click or Space Fire a red ballistic shell
  R                   Reset encounter
  Esc                 Release mouse; press again to quit

Requires: Windows 10/11 x64 and a GPU/driver supporting OpenGL 3.3 or newer.
